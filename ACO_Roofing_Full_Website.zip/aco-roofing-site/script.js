const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');

toggle?.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  toggle.textContent = open ? '✕' : '☰';
});

document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  toggle?.setAttribute('aria-expanded', 'false');
  if (toggle) toggle.textContent = '☰';
}));

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

document.getElementById('year').textContent = new Date().getFullYear();

function handleDemoForm(form, statusSelector) {
  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    const status = form.querySelector(statusSelector);
    if (status) status.textContent = 'Thanks — this demo form is ready to connect to your email or CRM.';
    else alert('Thanks! This demo form can be connected to email, Formspree, Netlify Forms, or a CRM before launch.');
    form.reset();
  });
}

handleDemoForm(document.getElementById('quoteForm'), '.form-status');
handleDemoForm(document.getElementById('contactForm'), '.form-status');
