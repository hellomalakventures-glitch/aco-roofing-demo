# ACO Roofing & Gutters — Website Concept

Responsive static website concept for ACO Roofing & Gutters in Dallas, Texas.

## Files
- `index.html`
- `styles.css`
- `script.js`

## Publish on GitHub Pages
1. Create a new GitHub repository.
2. Upload these three files to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. GitHub will generate a public demo URL.

## Before a real client launch
- Replace demo review text with verified customer reviews.
- Confirm business hours, service area, phone, email, licenses/insurance claims, and services directly with the business.
- Connect both forms to Formspree, Netlify Forms, a CRM, or the client's email backend.
- Add the client's real logo and project photos.
- Add Privacy Policy / Terms if needed.

## Current demo details
- Phone: (214) 228-3871
- Address: 8035 E R L Thornton Fwy #269, Dallas, TX 75228
- Google listing screenshot supplied by user showed 5.0 stars and 71 reviews.
